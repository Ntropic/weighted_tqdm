# -*- coding: utf-8 -*-

from weighted_tqdm.weighted_tqdm import *